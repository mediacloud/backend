package Carton::Error;
use strict;
use Exception::Class (
    'Carton::Error::CommandExit',
);

1;
